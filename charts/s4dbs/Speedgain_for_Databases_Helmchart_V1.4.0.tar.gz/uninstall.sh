helm uninstall s4dbschart
