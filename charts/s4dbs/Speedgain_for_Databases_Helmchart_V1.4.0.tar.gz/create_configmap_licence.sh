#! /bin/bash
kubectl create configmap s4dbs-licence --from-file ./licence/Speedgain_for_Databases.licence
